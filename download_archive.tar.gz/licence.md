## Лицензия (Русский)
### СКАЧИВАЯ ЭТО ПРИЛОЖЕНИЕ ВЫ АВТОМАТИЧЕСКИ СОГЛАШАЕТЕСЬ С ЭТИМ ДОКУМЕНТОМ
<br>



#### 1. Авторские права
© 2026 SG123it. Все права защищены.

#### 2. Запрет на декомпиляцию и обратную разработку
Запрещается декомпилировать, деассемблировать, выполнять reverse engineering или иным способом пытаться извлечь исходный код из программного обеспечения (включая исполняемые файлы и библиотеки), за исключением случаев, прямо разрешённых действующим законодательством.

#### 3. Запрет на распространение исходного кода
Запрещено распространять исходный код (или его производные) без письменного разрешения правообладателя.

#### 4. Ограничение ответственности
Программное обеспечение предоставляется «как есть». Автор не несёт ответственности за прямые или косвенные убытки, возникшие в результате использования программы.

#### 5. Применимое право
Настоящая лицензия регулируется законодательством страны, в которой зарегистрирован правообладатель.

<br><hr><br>


## License (English)
### BY DOWNLOADING THIS APPLICATION, YOU AUTOMATICALLY AGREE TO THIS DOCUMENT.
<br><br>


#### 1. Copyright
© 2026 SG123it. All rights reserved.

#### 2. No reverse engineering / decompilation
You may not decompile, disassemble, perform reverse engineering, or otherwise attempt to derive the source code from the software (including executable files and libraries), except where such restriction is prohibited by applicable law.

#### 3. No source code redistribution
No redistribution of the source code (or derivative works) is allowed without the copyright holder’s prior written permission.

#### 4. Disclaimer of liability
The software is provided “as is”. The author is not liable for any direct or indirect damages resulting from the use of the program.

#### 5. Governing law
This license is governed by the laws of the country where the copyright holder is registered.

